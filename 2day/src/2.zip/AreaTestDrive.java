public class AreaTestDrive {

    public static void main(String[] args) {
        Square square = new Square(20);
        square.calculateArea();
        Rectangle rectangle = new Rectangle(2,3);
        rectangle.calculateArea();
    }
}
